import { CSAgentUser } from './call-service-agent-user';
import { TSOUser } from './tso-user';
/*
    TsoDetail
        regionCodeNavigation
            provinceCodeNavigation
        salePointCodeNavigation

    UserDetail
        userRoleCodeNavigation
*/
export class TsoCcUser {
    TsoDetail: TSOUser;
    UserDetail: CSAgentUser;

    constructor() {
        this.TsoDetail = new TSOUser();
        this.UserDetail = new CSAgentUser();
    }
}