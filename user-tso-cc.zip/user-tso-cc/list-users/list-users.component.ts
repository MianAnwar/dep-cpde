import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { MockData } from 'src/constants/mock-data';
import { DataSharingService } from 'src/services/data-sharing.service';
import { TsoCcUser } from '../user-tso-cc';
import { UsersService } from '../user-tso-cc.service';
import { first } from 'rxjs/operators';
import { AppPersistentUtilityService, UsersPersistent } from 'src/services/app-persistent-utility.service';
import { cellPhoneFormatter } from 'src/_helpers/cell-phone-fomatter'; import { CSAgentUser } from '../call-service-agent-user';

@Component({
  selector: 'app-list-users',
  templateUrl: './list-users.component.html',
  styleUrls: ['./list-users.component.css']
})
export class ListUsersComponent implements OnInit, OnDestroy {
  usersstatus: any[] = [{ label: 'TSO', value: 'TSO' }, { label: 'Call service agent', value: 'Call service' }];
  searchOptions = ['CellPhone', 'UserName'];
  selectedValue;

  private searchedValue: string = "";
  private searchedcat: string;
  searchvalue;
  private params: string;
  breadcrumbUrl;
  currentpage;
  showBoundaryLinks = true;

  private currentPage: number = 0;
  public recordsPerPage: number = 15;
  public totalrecords: number = 0;

  private pages: number = 1;
  public colDef: any[];
  public workFlowViewcolumnDefs: any[];
  public workFlowViewrowData: any[];
  public runProcessCellCallback: boolean = true;

  tsoCcUsers: CSAgentUser[];

  constructor(
    private cellPhoneFormatter: cellPhoneFormatter,
    private _appPersistenceUtility: AppPersistentUtilityService,
    public usersService: UsersService,
    private router: Router, private dataSharingService: DataSharingService) {
  }

  ngOnDestroy(): void {
    this._appPersistenceUtility.farmerPersistence
      .next(
        new UsersPersistent(
          (this.breadcrumbUrl == "" ? 0 : this.breadcrumbUrl),
          this.currentpage,
          this.totalrecords,
          this.searchedcat, this.searchedValue,
          this.tsoCcUsers,
          true)
      );
  }

  setPage(): void {
    this._appPersistenceUtility.farmerPersistence.subscribe(res => {
      if (res.currentPageNumber !== 0 && res.data !== null) {
        this.breadcrumbUrl = res.appTab;
        this.currentpage = res.currentPageNumber;
        this.searchedcat = res.cat;
        this.searchedValue = res.val;
        this.tsoCcUsers = res.data;
        this.totalrecords = res.totalPages;
      } else {
        this.currentpage = 1;
      }
    });
  }

  ngOnInit() {
    this.setPage();

    if (this.breadcrumbUrl == 0 || this.breadcrumbUrl == undefined) {
      this.params = 'pageNumber=' + (this.currentpage - 1) + '&pageSize=' + this.recordsPerPage;
    }
    else {
      this.params = 'pageNumber=' + (this.currentpage - 1) + '&pageSize=' + this.recordsPerPage + '&filter=' + this.searchedcat + '&value=' + this.searchedValue;
    }

    // set active tab status
    this.selectedValue = "CellPhone";
    this.dataSharingService.activeBreadCrumburl('Users');

    this.usersService.getAllUsers(this.params)
      .pipe(first())
      .subscribe(data => {
        this.tsoCcUsers = data["data"];
        console.log("tsoCcUsers: ", this.tsoCcUsers);
        this.totalrecords = data['totalCount'];
        this.getWfGridData();
      });
  }

  addedit(id) {
    this.router.navigate(['/admin/user/' + id]);
  }

  search(searchcat: string, searchval: string) {
    this.searchedcat = searchcat;
    this.searchedValue = searchval;

    if (this.searchedcat == 'UserName' || this.searchedcat == 'CellPhone') {
      if (this.searchedcat == 'CellPhone') this.searchedValue = this.cellPhoneFormatter.reformatPhoneNoServer(this.searchedValue);
      this.params = 'pageNumber=' + this.currentPage + '&pageSize=' + this.recordsPerPage + '&filter=' + this.searchedcat + '&value=' + this.searchedValue;
    }
    if (this.searchedValue == "") {
      this.params = 'pageNumber=' + this.currentPage + '&pageSize=' + this.recordsPerPage;
      this.breadcrumbUrl = 0;
      this._appPersistenceUtility.farmerPersistence
        .next(new UsersPersistent(0, this.currentpage, this.totalrecords, null, null, this.tsoCcUsers, true));

    }
    else {
      // for status (send A for Active and I for Inactive (case-insensitive search))
      if (this.searchedcat == "RoleName") {
        this.params = 'pageNumber=' + this.currentPage + '&pageSize=' + this.recordsPerPage + '&filter=' + this.searchedcat + '&value=' + this.searchedValue;
        this.breadcrumbUrl = searchval;
        this._appPersistenceUtility.farmerPersistence
          .next(new UsersPersistent(this.breadcrumbUrl, this.currentpage, this.totalrecords, this.searchedcat, this.searchedValue, this.tsoCcUsers, true));
      }
    }

    console.log("Parameters: ", this.params);
    this.usersService.getAllUsers(this.params)
      .pipe(first())
      .subscribe(data => {
        this.tsoCcUsers = data["data"];
        console.log("tsoCcUsers: ", this.tsoCcUsers);
        this.totalrecords = data['totalCount'];
        this.getWfGridData();
      });
    this.currentpage = 1;
  }


  //////////////////////////
  pageChanged(event: any) {
    this.pages = event.page;
    this.pages = this.pages - 1;
    if (this.searchedValue == "") {
      this.params = 'pageNumber=' + this.pages + '&pageSize=' + this.recordsPerPage;
    }
    else {
      this.params = 'pageNumber=' + this.pages + '&pageSize=' + this.recordsPerPage + '&filter=' + this.searchedcat + '&value=' + this.searchedValue;
    }
    this.usersService.getAllUsers(this.params)
      .pipe(first())
      .subscribe(data => {
        this.tsoCcUsers = data["data"];
        console.log("tsoCcUsers: ", this.tsoCcUsers);
        this.totalrecords = data['totalCount'];
        this.getWfGridData();
      });
  }
  onGridReady(params) {
    params.api.sizeColumnsToFit();
  }
  getWfGridData() {

    this.colDef = MockData.agGridColumnDefs_Users;
    //const rowDef: any[] = MockData.agGridRowDefs_News;
    this.workFlowViewcolumnDefs = this.colDef;
    console.log("workFlowViewcolumnDefs:", this.workFlowViewcolumnDefs);
    this.workFlowViewrowData = this.tsoCcUsers;
    console.log("workFlowViewrowData:", this.workFlowViewrowData);
  }


}
