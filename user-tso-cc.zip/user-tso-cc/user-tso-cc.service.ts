import { TSOCSAViewModel } from './tso-cc-view-model';
import { CSAgentUser } from './call-service-agent-user';
import { UserRoles } from './userRoles';
import { TsoCcUser } from './user-tso-cc';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from 'src/constants/app-config';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { Salespoint } from 'src/models/salespoint';
import { Province } from 'src/models/province';
import { Region } from 'src/models/region';
import { TSOUser } from './tso-user';
import { Tehsil } from 'src/models/tehsil';
import { CallServiceAgentViewModel } from './call-service-agent-view-model';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  constructor(private http: HttpClient, private ts: ToastrService) {
  }

  getAllUsers(params: string) {
    console.log("params", params)
    return this.http.get<CSAgentUser[]>(`${AppConfig.URL_User}GetTsoAndCSAUser?` + params)
      .pipe(
        map(x => {
          console.log(x);
          return x["data"]
        }),
        tap(_ => console.log('fetched users')),
        catchError(this.handleError('getusers'))
      );
  }

  getAllRoles() {
    return this.http.get<UserRoles[]>(`${AppConfig.URL_User}Roles`)
      .pipe(
        map(x => {
          return x["data"]
        }),
        tap(_ => console.log('fetched user\'s roles')),
        catchError(this.handleError('get user\'s roles'))
      );
  }

  // CALL SERVICE AGENT - START
  getDistricts(id, isTSO) {
    return this.http.get<Region>(`${AppConfig.URL_Lookup}DistrictsOfProvince/${id}`).pipe(
      map(x => x["data"]),
      tap(_ => console.log(`getDistricts`)),
      catchError(this.handleError<any>('getDistricts'))
    );
  }
  getTehsils(id) {
    return this.http.get<Tehsil>(`${AppConfig.URL_Lookup}TehsilsOfDistrict/${id}`).pipe(
      map(x => x["data"]),
      tap(_ => console.log(`getTehsils`)),
      catchError(this.handleError<any>('getTehsils'))
    );
  }
  // CALL SERVICE AGENT -END

  getSalePoints() {
    return this.http.get<Salespoint>(`${AppConfig.URL_Lookup}GetAllSalesPoint`).pipe(
      map(x => x["data"]),
      tap(_ => console.log(`getSalePoints`)),
      catchError(this.handleError<any>('getSalePoints'))
    );
  }
  getProvinces() {
    return this.http.get<Province>(`${AppConfig.URL_Lookup}Province`).pipe(
      map(x => x["data"]),
      tap(_ => console.log(`getProvinces`)),
      catchError(this.handleError<any>('getProvinces'))
    );
  }
  getRegions(id, isTSO) {
    return this.http.get<Region>(`${AppConfig.URL_Lookup}CitiesOfProvince/${id}?isTSO=${isTSO}`).pipe(
      map(x => x["data"]),
      tap(_ => console.log(`getRegions`)),
      catchError(this.handleError<any>('getRegions'))
    );
  }

  // get by filers: (key,value)  key=> userName, cellPhone OR email, cnic.
  getUserExistanceByFilter(params: String) {
    return this.http.get<CSAgentUser>(`${AppConfig.URL_User}IsUserExist?` + params)
      .pipe(
        map(x => {
          return x["data"]
        }),
        tap(_ => console.log(`Get user existence.`)),
        catchError(this.handleError<any>('Could not get data, try later.'))
      );
  }
  // get by filers: (key,value)  key=> userName, cellPhone OR email, cnic.
  getTSOExistanceByFilter(params: String) {
    return this.http.get<TSOUser>(`${AppConfig.URL_TSO}IsTSOExist?` + params)
      .pipe(
        map(x => {
          return x["data"]
        }),
        tap(_ => console.log(`Get user existence.`)),
        catchError(this.handleError<any>('Could not get data, try later.'))
      );
  }

  // add User <in Tb_Login and Tb_TSOinfo>
  addUser(user: TSOCSAViewModel): Observable<TSOUser> {
    return this.http.post<TSOUser>(`${AppConfig.URL_TSO}`, user)
      .pipe(
        map(x => {
          debugger
          return x;
        }),
        tap(
          (user: TSOUser) =>
            console.log(`added User w/ id=${user.tsoid}`)
        ),
        catchError(
          this.handleError<TSOUser>('Record already exist.')
        )
      );
  }
  // add User <in Tb_Login and Tb_TSOinfo>
  addCallAgentUser(user: CallServiceAgentViewModel): Observable<TSOUser> {
    debugger
    return this.http.post<TSOUser>(`${AppConfig.URL_CallCenter}`, user)
      .pipe(
        map(x => {
          debugger
          return x;
        }),
        tap(
          (user: TSOUser) =>
            console.log(`added User w/ id=${user}`)
        ),
        catchError(
          this.handleError<TSOUser>('Record already exist.')
        )
      );
  }

  // update User <complete in Tb_Login and Tb_TSOinfo>
  updateUser(user: TSOCSAViewModel) {
    return this.http.put(`${AppConfig.URL_TSO}${user.tsoid}`, user)
      .pipe(
        tap(_ => console.log(`updated user of id=${user["userId"]}`)),
        catchError(this.handleError<any>('Could not update, try later.'))
      );
  }

  // get by userID.
  getUser(id: String) {
    return this.http.get<TsoCcUser>(`${AppConfig.URL_TSO}GetTSODetailInfo?id=` + id)
      .pipe(
        map(x => {
          return x["data"]
        }),
        tap(_ => console.log(`Get user of id=${id}`)),
        catchError(this.handleError<any>('Could not get data, try later.'))
      );
  }

  // deactivate user
  deActivateUser(id: String, status: String): Observable<CSAgentUser> {
    const url = `${AppConfig.URL_User}UpdateUserStatus?id=` + id + `&status=` + status;
    return this.http.put(url, null)
      .pipe(
        tap(_ => console.log(`updated status user of id=${id}`)),
        catchError(this.handleError<any>('Could not update status, try later.'))
      );
  }



  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.log(`${operation} failed: ${error.message}`);
      //this.ts.error("Failed to Perform Operation");
      return of(result as T);
    };
  }

  private log(message: string) {
    // console.log(message);
    this.ts.success("Operation Performed Successfully");
  }
}
