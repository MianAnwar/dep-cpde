export class UserRoles {
  "userRoleCode"?: number;
  "roleName"?: string;
  "roleNameUrdu"?: string;

  "activeStatus"?: string;
  "insertionDate"?: string;
  "modifiedBy"?: number;
}