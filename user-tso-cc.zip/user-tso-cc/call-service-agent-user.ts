import { UserRoles } from "./userRoles";

export class CSAgentUser {
  "userId": string;
  "cellPhone": string;
  "userName": string;
  "passkey": string;
  "userRoleCode": number;
  "modifiedBy": string;
  "modifiedDateTime": string;
  "insertionDate": string;
  "activeStatus": string;
  "userRoleCodeNavigation": UserRoles;
}
