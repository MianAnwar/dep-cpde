/*
  tbUserDetail => userId", "cellPhone", "userName",
                "passkey": "kkkkk",
                "userRoleCode": 2,
    userRoleCodeNavigation

  tbRegionCodeNavigation
*/
import { CSAgentUser } from './call-service-agent-user';
import { RegionNav } from './tso-user';

export class UserViewModel {
  "tbUserDetail"?: CSAgentUser;
  "TbRegionCodeNavigation"?: RegionNav;
}