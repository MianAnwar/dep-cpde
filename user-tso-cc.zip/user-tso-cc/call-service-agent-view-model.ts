export class CallServiceAgentViewModel {
  "userGuid"?: string;
  "callCenterAgentId": number;
  "agentName"?: string;
  "cnic"?: string;
  "email"?: string;
  "gender"?: string;
  "landline"?: string;



  //optionals
  "alternateCellPhone"?: string;
  "presentAddress"?: string;
  "permanentAddress"?: string;
  "educationCode"?: string;
  "tehsilCode"?: string;
  "districtCode"?: string;
  "tsoImage"?: string;

  "userId": string;
  "cellPhone": string;
  "userName": string;
  "passkey": string;
  "userRoleCode": number;
  "modifiedBy": string;
  "modifiedDateTime": string;
  "insertionDate": string;
  "activeStatus": string;
}