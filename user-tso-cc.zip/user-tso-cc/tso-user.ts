import { Tehsil } from './../../models/tehsil';
import { District } from './../../models/district';
import { Province } from "src/models/province";
import { Salespoint } from "src/models/salespoint";

export class TSOUser {
  "userGuid"?: string;
  "tsoid": number;
  "tsoname"?: string;
  "cnic"?: string;
  "email"?: string;
  "cellPhone"?: string;
  "gender"?: string;
  "landline"?: string;

  "modifiedBy"?: string;
  "modifiedDateTime"?: string;
  "insertionDate"?: string;

  "activeStatus"?: string;

  //optionals
  "alternateCellPhone"?: string;
  "presentAddress"?: string;
  "permanentAddress"?: string;
  "educationCode"?: string;

  // for tso
  "salePointCode"?: string;
  "regionCode"?: string;
  // for call-service-agent
  "districtCode"?: string;
  "tehsilCode"?: string;


  "tsoImage"?: string;

  // for tso
  "regionCodeNavigation": RegionNav;
  "salePointCodeNavigation": Salespoint;
  // for call-service-agent
  "districtCodeNavigation"?: District;
  "tehsilCodeNavigation"?: Tehsil;
}

export class RegionNav {
  "regionCode": number;
  "regionName": string;
  "regionNameUrdu": string;
  "provinceCode": number;
  "provinceCodeNavigation": Province;
}

