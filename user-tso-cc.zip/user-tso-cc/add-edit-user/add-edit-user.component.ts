import { TSOCSAViewModel } from './../tso-cc-view-model';
import { TsoCcUser } from './../user-tso-cc';
import { UserRoles } from './../userRoles';
import { Component, ElementRef, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { first } from 'rxjs/operators';
import { DataSharingService } from 'src/services/data-sharing.service';
import { UsersService } from '../user-tso-cc.service';
import { cellPhoneFormatter } from 'src/_helpers/cell-phone-fomatter';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Region } from 'src/models/region';
import { Province } from 'src/models/province';
import { ToastrService } from 'ngx-toastr';
import { District } from 'src/models/district';
import { Tehsil } from 'src/models/tehsil';
import { CallServiceAgentViewModel } from '../call-service-agent-view-model';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.css']
})
export class AddEditUserComponent implements OnInit {
  form: FormGroup;
  public userRoles: UserRoles[];
  myDate = new Date();

  public readOnly = false;
  id: String;
  isNew: boolean = false;
  user: TsoCcUser = new TsoCcUser();
  userInfo: TSOCSAViewModel = new TSOCSAViewModel();

  provinces: Province[];
  regions: Region[];
  districts: District[];
  tehsils: Tehsil[];
  salepoints: any[];

  isTSO;

  selectedProvince;

  activeStatus: boolean = false;
  genders = ['Male', 'Female', 'Others'];

  constructor(
    private cellPhoneFormatter: cellPhoneFormatter,
    private location: Location,
    fb: FormBuilder, private route: ActivatedRoute,
    public usersService: UsersService,
    private ts: ToastrService,
    private router: Router, private dataSharingService: DataSharingService
  ) {
    this.form = fb.group({
      "userRoleCode": ["", Validators.required],
      "cellPhone": ["", [Validators.required, Validators.minLength(12)]],
      "userName": ["", Validators.required],
      "passkey": ["", Validators.required],
      "activeStatus": [""],
      "tsoName": ["", Validators.required],
      "gender": ["", Validators.required],
      "cnic": ["", [Validators.pattern("([0-9]{5}-)[0-9]{7}-[0-9]{1}"), Validators.minLength(15)]],
      "email": ["", [Validators.required, Validators.email]],
      "alternateCellPhone": ["", [Validators.pattern("(\([0-9]{4}\) |[0-9]{4}-)[0-9]{7}"), Validators.minLength(12)]],
      "landline": ["", [Validators.pattern("[0-9]*"), Validators.maxLength(13)]],
      "presentAddress": [""],
      "permanentAddress": [""],
      "salePointCode": [""],
      "educationCode": [""],
      "provinceCode": ["", Validators.required],
      "regionCode": [""],
      "districtCode": [""],
      "tehsilCode": [""],
      "tsoImage": [""],
    });
  }

  get f() { return this.form.controls; }

  ngOnInit() {
    // set active tab status
    this.dataSharingService.activeBreadCrumburl('Users');

    // get and route params, [id+readOnly]
    this.id = this.route.snapshot.paramMap.get('id');
    this.route.queryParams
      .filter(params => params.view)
      .subscribe(params => {
        this.readOnly = params.view;
        (this.readOnly) ? this.ReadOnly() : null;
      });

    this.getRoles();
    this.getProvinces();
    this.getSalePoints();
    this.getUser();
  }
  checkIsTSO() {
    return this.userRoles && this.userRoles!.filter(x => x.roleName.startsWith("TSO"))[0].userRoleCode == this.user.UserDetail.userRoleCode ? 1 : 0;
  }
  getUser() {
    this.isTSO = this.checkIsTSO();
    if (this.id.length == 36) {
      this.usersService.getUser(this.id)
        .subscribe(data => {
          if (data) {
            this.user = data;
            if (this.user.TsoDetail.regionCode) {
              this.selectedProvince = this.user.TsoDetail.regionCodeNavigation!.provinceCode;
              this.usersService.getRegions(this.selectedProvince, this.checkIsTSO())
                .subscribe(data => {
                  this.regions = data;
                  this.f.regionCode.setValue(this.user.TsoDetail.regionCode);
                });
            }
            if (this.user.TsoDetail.alternateCellPhone)
              this.user.TsoDetail.alternateCellPhone = this.cellPhoneFormatter.reformatPhoneNoClient(this.user.TsoDetail.alternateCellPhone);
            this.user.UserDetail.cellPhone = this.cellPhoneFormatter.reformatPhoneNoClient(this.user.UserDetail.cellPhone);
            this.f.activeStatus.setValue(this.user.UserDetail.activeStatus == "A" ? true : false);
            this.activeStatus = this.user.UserDetail.activeStatus == "A" ? true : false;
            this.f.gender.setValue(this.user.TsoDetail.gender);
          }
          else {
            this.ts.show("No data exist for this user.");
            this.goBack();
          }
        })
      this.ReadOnlyForEdit();
    } else {
      this.isNew = true;
    }
  }


  getRoles() {
    this.usersService.getAllRoles()
      .pipe(first())
      .subscribe(data => {        // this.userRoles = data;
        this.userRoles = data.filter(x => (x.roleName.startsWith("TSO") || x.roleName.startsWith("Call service agent")));
        if (this.user.TsoDetail.regionCode) {
          this.selectedProvince = this.user.TsoDetail.regionCodeNavigation!.provinceCode;
          this.usersService.getRegions(this.selectedProvince, this.checkIsTSO())
            .subscribe(data => {
              this.regions = data;
              this.f.regionCode.setValue(this.user.TsoDetail.regionCode);
            });
        }
      });
  }
  getSalePoints() {
    this.usersService.getSalePoints().subscribe(data => {
      this.salepoints = data;
    });
  }
  getProvinces() {
    this.usersService.getProvinces().subscribe(data => {
      this.provinces = data;
    });
  }
  getRegionsOrDistricts(id: any) {
    this.isTSO = this.checkIsTSO();
    if (this.isTSO) {
      if (id != null) {
        this.usersService.getRegions(id, this.isTSO).subscribe(data => {
          this.regions = data;
        });
      } else {
        this.usersService.getRegions(1, this.isTSO).subscribe(data => {
          this.regions = data;
        });
      }
    }
    else {
      if (id != null) {
        this.usersService.getDistricts(id, this.isTSO).subscribe(data => {
          this.districts = data;
          this.user.TsoDetail.districtCode = 'Select District'
        });
      } else {
        this.usersService.getDistricts(1, this.isTSO).subscribe(data => {
          this.districts = data;
          this.user.TsoDetail.districtCode = 'Select District'
        });
      }
    }
  }

  getTehsils() {
    this.usersService.getTehsils(this.user.TsoDetail.districtCode).subscribe(data => {
      this.tehsils = data;
      this.user.TsoDetail.tehsilCode = "Select Tehsil";
    });
  }

  newRoleSelected() {
    this.selectedProvince = null;
    this.isTSO = this.checkIsTSO();
  }

  setModel(user) {
    this.userInfo = user;
    if (!this.isNew)
      this.userInfo.insertionDate = this.user.UserDetail.insertionDate;
    if (this.form.controls.alternateCellPhone.errors == null)
      this.userInfo.alternateCellPhone = this.user.TsoDetail.alternateCellPhone;
    this.userInfo.activeStatus = this.user.UserDetail.activeStatus;
    this.userInfo.cellPhone = this.user.UserDetail.cellPhone;
    this.userInfo.userGuid = this.user.TsoDetail.userGuid;
    this.userInfo.userId = this.user.UserDetail.userId;
    this.userInfo.tsoid = this.user.TsoDetail.tsoid;
    this.userInfo.userRoleCode = this.user.UserDetail.userRoleCode;
    this.userInfo.insertionDate = this.user.UserDetail.insertionDate;
    this.userInfo.regionCode = this.user.TsoDetail.regionCode;
  }

  goBack() {
    this.location.back();
  }

  save() {
    debugger
    if (this.form.valid) {
      if (this.form.controls.alternateCellPhone.errors == null && this.form.controls.alternateCellPhone.value && this.form.controls.alternateCellPhone.value != "")
        this.user.TsoDetail.alternateCellPhone = this.cellPhoneFormatter.reformatPhoneNoServer(this.user.TsoDetail.alternateCellPhone);
      this.user.UserDetail.cellPhone = this.cellPhoneFormatter.reformatPhoneNoServer(this.user.UserDetail.cellPhone);
      this.user.UserDetail.activeStatus = this.activeStatus ? 'A' : 'I';
      this.user.TsoDetail.gender = this.f.gender.value;
      this.setModel(this.form.value);
      if ((this.id == 'n-e-w' || this.id == undefined) && this.id.length != 36) {
        if (this.isTSO) {
          this.usersService.addUser(this.userInfo)
            .pipe(first())
            .subscribe(x => {
              debugger
              // x = {responseCode: 1, responseMessage: 'phone number already registered.', data: null}
              if (x["responseCode"] == 0) {
                this.ts.success("New TSO User is added successfully.");
                this.formatAlternativePhoneNoForClient();

                this.goBack();
              }
              else {
                this.user.UserDetail.cellPhone = this.cellPhoneFormatter.reformatPhoneNoClient(this.user.UserDetail.cellPhone);
                this.formatAlternativePhoneNoForClient();
                this.ts.show(x["responseMessage"]);
              }
            });
        }
        else {
          let callagent = this.parseTSOtoCallAgent();
          this.usersService.addCallAgentUser(callagent)
            .pipe(first())
            .subscribe(x => {
              debugger
              // x = {responseCode: 1, responseMessage: 'phone number already registered.', data: null}
              if (x["responseCode"] == 0) {
                this.ts.success("New record is added successfully.");
                this.formatAlternativePhoneNoForClient();

                this.goBack();
              }
              else {
                this.user.UserDetail.cellPhone = this.cellPhoneFormatter.reformatPhoneNoClient(this.user.UserDetail.cellPhone);
                this.formatAlternativePhoneNoForClient();
                this.ts.show(x["responseMessage"]);
              }
            });
        }

      }
      else {
        debugger
        this.usersService.updateUser(this.userInfo)
          .pipe(first())
          .subscribe(data => {
            debugger
            if (data != undefined) {
              this.ts.success("Record is updated successfully.");
              this.goBack();
            }
          });
      }
    } else {
      this.ts.show("Must fill all required fields.");
    }
  }
  parseTSOtoCallAgent(): CallServiceAgentViewModel {
    let agent = new CallServiceAgentViewModel();
    debugger
    agent.userGuid = this.userInfo.userGuid;
    agent.cnic = this.userInfo.cnic;
    agent.email = this.userInfo.email;
    agent.gender = this.userInfo.gender;
    agent.landline = this.userInfo.landline;
    agent.alternateCellPhone = this.userInfo.alternateCellPhone;
    agent.presentAddress = this.userInfo.presentAddress;
    agent.permanentAddress = this.userInfo.permanentAddress;
    agent.educationCode = this.userInfo.educationCode;
    agent.tsoImage = this.userInfo.tsoImage;
    agent.userId = this.userInfo.userId;
    agent.cellPhone = this.userInfo.cellPhone;
    agent.userName = this.userInfo.userName;
    agent.passkey = this.userInfo.passkey;
    agent.userRoleCode = this.userInfo.userRoleCode;
    agent.modifiedBy = this.userInfo.modifiedBy;
    agent.modifiedDateTime = this.userInfo.modifiedDateTime;
    agent.insertionDate = this.userInfo.insertionDate;
    agent.activeStatus = this.userInfo.activeStatus;

    agent.callCenterAgentId = this.userInfo.tsoid;//
    agent.agentName = this.userInfo.tsoName;//
    agent.tehsilCode = this.user.TsoDetail.tehsilCode;//
    agent.districtCode = this.user.TsoDetail.districtCode;//
    return agent;
  }

  formatAlternativePhoneNoForClient() {
    if (this.form.controls.alternateCellPhone.errors == null && this.form.controls.alternateCellPhone.value && this.form.controls.alternateCellPhone.value != "")
      this.user.TsoDetail.alternateCellPhone = this.cellPhoneFormatter.reformatPhoneNoClient(this.user
        .TsoDetail.alternateCellPhone);
  }

  getUserDetail(key?: string, value?: string) {
    if (key == "CNIC" && this.f.cnic.errors) {
      document.getElementById("cnic").focus();
      this.ts.show("Incorrect CNIC");
      return;
    }
    if (key == "Email" && this.f.email.errors) {
      document.getElementById("email").focus();
      this.ts.show("Incorrect Email");
      return;
    }
    if (key == "CellPhone") {
      if (this.f.cellPhone.errors) {
        document.getElementById("phone").focus();
        this.ts.show("Incorrect Cell-Phone");
        return;
      }
      else {
        value = this.cellPhoneFormatter.reformatPhoneNoServer(value);
      }
    }

    if (key && value) {
      let params = "filter=" + key + "&value=" + value;
      console.log(params)
      // phone=923111111111
      if (key == 'Email' || key == 'CNIC') {
        this.usersService.getTSOExistanceByFilter(params).pipe(first()).subscribe(data => {
          // it means already exists
          if (data) {
            if (key == 'CNIC')
              this.form.controls['cnic'].setErrors({ cnicExist: `CNIC # already exists` });
            if (key == 'Email')
              this.form.controls['email'].setErrors({ emailExist: `Email already exists` });
          }
        });
      }
      else if (key == 'UserName' || key == 'CellPhone') {
        this.usersService.getUserExistanceByFilter(params).pipe(first()).subscribe(data => {
          if (data) {
            if (key == 'CellPhone')
              this.form.controls['cellPhone'].setErrors({ cellPhoneExist: `Cell Phone already exists` });
            if (key == 'UserName')
              this.form.controls['userName'].setErrors({ userNameExist: `UserName already exists` });
          }
        });
      }

    }
  }
  ReadOnlyForEdit() {
    this.form.controls['userRoleCode'].disable();
    // this.form.controls['salePointCode'].disable();
    this.form.controls['provinceCode'].disable();
    this.form.controls['regionCode'].disable();
  }

  ReadOnly() {
    this.form.controls['userRoleCode'].disable();
    this.form.controls['cellPhone'].disable();
    this.form.controls['userName'].disable();
    this.form.controls['passkey'].disable();
    this.form.controls['activeStatus'].disable();
    this.form.controls['tsoName'].disable();
    this.form.controls['gender'].disable();
    this.form.controls['cnic'].disable();
    this.form.controls['email'].disable();
    this.form.controls['alternateCellPhone'].disable();
    this.form.controls['landline'].disable();
    this.form.controls['presentAddress'].disable();
    this.form.controls['permanentAddress'].disable();
    this.form.controls['salePointCode'].disable();
    this.form.controls['educationCode'].disable();
    this.form.controls['provinceCode'].disable();
    this.form.controls['regionCode'].disable();
    this.form.controls['tsoImage'].disable();
  }
}
