export class TSOCSAViewModel {
  "userGuid"?: string;
  "tsoid": number;
  "tsoName"?: string;
  "cnic"?: string;
  "email"?: string;
  "gender"?: string;
  "landline"?: string;



  //optionals
  "alternateCellPhone"?: string;
  "presentAddress"?: string;
  "permanentAddress"?: string;
  "educationCode"?: string;
  "salePointCode"?: string;
  "regionCode"?: string;
  "tsoImage"?: string;

  "userId": string;
  "cellPhone": string;
  "userName": string;
  "passkey": string;
  "userRoleCode": number;
  "modifiedBy": string;
  "modifiedDateTime": string;
  "insertionDate": string;
  "activeStatus": string;
}